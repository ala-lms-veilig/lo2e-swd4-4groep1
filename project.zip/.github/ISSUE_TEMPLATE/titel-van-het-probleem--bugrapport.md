---
name: 'Titel van het probleem: Bugrapport'
about: Maak een rapport om ons te helpen verbeteren
title: ''
labels: ''
assignees: ''

---

Beschrijf de bug
Een duidelijke en beknopte beschrijving van wat de bug is.

Stappen om te reproduceren
Stappen om het gedrag te reproduceren:

Ga naar '...'
Klik op '...'
Scroll naar '...'
Zie fout
Verwacht gedrag
Een duidelijke en beknopte beschrijving van wat je verwachtte dat zou gebeuren.

Schermafbeeldingen
Voeg indien van toepassing schermafbeeldingen toe om je probleem uit te leggen.
